export interface Todo{
    // sno: number,
    title: string,
    desc: string

}