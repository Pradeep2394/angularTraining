import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  url:string="http://localhost:3000";
  constructor(private http:HttpClient) { }

  getAlltodos()
  {
    return this.http.get<any>(`${this.url}/todos`);
  }


  addtodo(todo:any)
  {
    return this.http.post<any>(`${this.url}/todos`, todo);
  }
}
