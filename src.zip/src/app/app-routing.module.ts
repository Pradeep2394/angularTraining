import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AddTodoComponent } from './MyComponents/add-todo/add-todo.component';
import { LoginComponent } from './MyComponents/login/login.component';
import { TodosComponent } from './MyComponents/todos/todos.component';
import { AuthService } from './services/auth.service';

const routes: Routes = [
  {path:'',  redirectTo:'login',pathMatch:'full'},
{path:'add', component:AddTodoComponent, canActivate:[AuthService]},
{path:'login', component:LoginComponent},
{path:'list', component:TodosComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
