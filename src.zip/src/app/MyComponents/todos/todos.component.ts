import { Component, OnInit } from '@angular/core';
import { TodoService } from 'src/app/services/todo.service';
import { Todo } from 'src/app/Todo';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  todos: Todo[];
  flag : boolean = true;
  constructor(private ps:TodoService) {
    this.todos = [
      // {
      //   sno:3,
      //   title: "This is Title3",
      //   desc: "description",
      //   active: true
      // },
      // {
      //   sno:2,
      //   title: "This is Title2",
      //   desc: "description",
      //   active: true
      // },
      // {
      //   sno:1,
      //   title: "This is Title1",
      //   desc: "description",
      //   active: true
      // }
    ]

   }
  

  ngOnInit(): void {
   if( this.todos == null)
   this.flag= false;

   this.ps.getAlltodos().subscribe( data => this.todos=data);
  }

  deleteTodo(todo: Todo){
    const index = this.todos.indexOf(todo);
    this.todos.splice(index,1)

  }

  addTodo(todo: Todo){
    
    this.todos.push(todo);
    console.log("abc");

  }

}
