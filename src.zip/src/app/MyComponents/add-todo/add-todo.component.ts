import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { Todo } from 'src/app/Todo';
import { TodoService } from 'src/app/services/todo.service';

@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']
})
export class AddTodoComponent implements OnInit {
 
  todo: Todo={
    // sno: 0,
    title: '',
    desc: ''
  };
  // todoform:FormGroup;
  // id:FormControl;
  //   title:FormControl;
  //   desc:FormControl;
  @Output() todoAdd: EventEmitter<Todo> = new EventEmitter();
  constructor(private ts :TodoService) {
  }

  ngOnInit(): void {
  }

  onSubmit(todo: any) {
    console.log(todo)
    console.log('title: ', todo.value.title);
    
    this.todoAdd.emit(todo.value);
    todo.reset();
  }

  addTodo(todo:any)
  {
    console.log("added")
    this.ts.addtodo(todo.value).subscribe((data: any) =>{
      if(data)
      {
        alert("Product added succesfully");
        // this.router.navigate(['list'])
      }
      else alert("Unable to add product, please try later");
    });
  }

}
